package com.library.bean;

/**
 * Author: JieYuDa
 * Desc:
 * File created at 2019/11/18
 */
public class ReaderInfoDate extends ReaderInfo {
    String birthday;

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }
}
